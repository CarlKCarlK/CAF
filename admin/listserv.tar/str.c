#include <ctype.h>

strcasecmp(a,b)
char *a, *b;
	{
	char *p;
	p = a;
	while (p && *p)
		{
		if (isupper(*p))
			*p = tolower(*p);
		p++;
		}
	p = b;
	while (p && *p)
		{
		if (isupper(*p))
			*p = tolower(*p);
		p++;
		}
	return(strcmp(a,b));
	}
strncasecmp(a,b,n)
char *a, *b;
int n;
	{
	char *p;
	p = a;
	while (p && *p)
		{
		if (isupper(*p))
			*p = tolower(*p);
		p++;
		}
	p = b;
	while (p && *p)
		{
		if (isupper(*p))
			*p = tolower(*p);
		p++;
		}
	return(strncmp(a,b,n));
	}
