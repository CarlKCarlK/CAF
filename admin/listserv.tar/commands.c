#include "listserv.h"

extern FILE *msg;
extern FILE *mailer;

sendhelp(from,request)
char *from, *request;
	{
	printf("called sendhelp with %s %s\n", from, request);
	callmailer("", from, request);
	mailcat(HELPFILE,"");
	pclose(mailer);
	return;
	}

listhelp(from,grp,request)
char *from,*grp,*request;
	{
	char tmp[128];
	printf("called listhelp with %s %s %s\n", from,grp,request);

	sprintf(tmp,"%s/%s.info", SERVDIR, grp);
	if (access(tmp,R_OK) != 0)
		{
		callmailer("", from, request);
		fprintf(mailer,"The mailing list \"%s\" could not be found.\n",
			grp);
		fprintf(mailer,"You may use the INDEX command to get a listing\n");
		fprintf(mailer,"of available mailing lists.\n");
		fflush(mailer);
		pclose(mailer);
		return;
		}

	callmailer("", from, request);
	fprintf(mailer,"Mailing list \"%s\":\n", grp);
	mailcat(tmp,"\t");
	pclose(mailer);
	return;
	}

sendindex(from,request,l)
char *from,*request;
int l;
	{
	FILE *ls;
	char tmp[128];
	char buf[128];
	int i;
	printf("called sendindex with %s %s %d\n", from,request,l);

	sprintf(tmp,"cd %s; ls *.info | sed -e 's/.info//", SERVDIR);
	ls = popen(tmp,"r");
	if (ls == NULL)
		{
		perror(tmp);
		exit(1);
		}
	callmailer("", from, request);
	fprintf(mailer,"Index of mailing lists\n");

	/* read the result of the ls */
	while (fgets(tmp, sizeof(tmp), ls))
		{
		while (tmp[(i=strlen(tmp)-1)] == '\n')
			tmp[i] = '\0';
		fprintf(mailer, "%s\n", tmp);

		/* if he wanted the long listing, cat the .info file */
		if (l)
			{
			sprintf(buf, "%s/%s.info", SERVDIR, tmp);
			mailcat(buf,"\t");
			fprintf(mailer, "\n");
			}
		}
	pclose(ls);
	pclose(mailer);
	return;
	}

