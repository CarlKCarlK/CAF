#include <stdio.h>
#include <strings.h>
#include <ctype.h>
#include <sys/file.h>


